#include <iostream>
#include <fstream>
#include <string>
using namespace std;




bool  get_Data(MovieData m[], string filename){
    string title;
    string director;
    int year;
    int runningTime;
    double productionCost;
    double firstYearRev;
    
    ifstream inputfile(filename);
    if(!inputfile){
    cout<< "Error"; 
    return false;
}
    

    for(int i = 0; i < 50; i++){
        inputfile >> title; 
        inputfile >> director;
        inputfile >> year;
        inputfile >> runningTime;
        inputfile >> productionCost;
        inputfile >> firstYearRev;

        MovieData w(title, director, year, runningTime, productionCost, firstYearRev);
        m[i] = w;
    }
    
   inputfile.close();
   return true;
   
}
//Prompts the user for the file name and calls the get data function. If the file doesn’t
//exist, the main function should continue to prompt the user until a valid filename is
//provided.
//o After the get_data function successfully completes, the main function should call
//the max_profit function, and display the object with the maximum profit.

int find_max_revenue(MovieData m[], int size){
    int MaxIndex = 0;
    double maxRev = 0.0;
    double currentRev = 0.0;

    for (int i = 0; i < size; i ++){
        
        m[i].GetfirstYearRevenues();
        currentRev = m[i].GetfirstYearRevenues () - m[i].GetproductionCost();
        maxRev = m[MaxIndex].GetfirstYearRevenues() - m[MaxIndex].GetproductionCost();
        if (currentRev > maxRev){
            MaxIndex = i;
        }
    }
    return MaxIndex;
}
////this is wrong 
//Prompts the user for the file name and calls the get data function. If the file doesn’t
//exist, the main function should continue to prompt the user until a valid filename is
//provided.
//o After the get_data function successfully completes, the main function should call
//the max_profit function, and display the object with the maximum profit.

///ignore this it is wrong
int main(){
    string title, director; 
    int yearReleased, runningTime; 
    double productionCost, firstYearRevenues; 
    int size;
    MovieData mymovie[size]; 
    cout<< "How many movies would you like to enter?";
    cin>> size;

    string filename;

    cout<< "What is the name of your file?";
    cin >> filename; 

    
    while(!get_Data(mymovie, filename)){
        cout<< "try again";
        cin>> filename;
    }
    cout<< find_max_revenue(mymovie, size);


    return 0;

}