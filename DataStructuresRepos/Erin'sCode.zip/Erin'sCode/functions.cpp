#include <iostream>
#include <fstream>
#include <string>
using namespace std;
MovieData::MovieData(string t, string d, int y, int r, double p, double f){
        title = t; 
        director = d; 
        yearReleased = y; 
        runningTime = r; 
        productionCost = p; 
        firstYearRevenues = f; 
}
void MovieData::Settitle(string t){
    title = t;
}
void MovieData::Setdirector(string d){
    director = d; 
}
void MovieData::SetyearReleased(int y){
    yearReleased = y;
}
void MovieData::SetrunningTime(int r){
    runningTime = r;
}
void MovieData::SetproductionCost(double p){
    productionCost = p;
}
void MovieData::SetfirstYearRevenues(double f){
    firstYearRevenues = f; 
}
string MovieData::Gettitle(){
    return title;
}
string MovieData::Getdirector(){
    return director;
}
int MovieData::GetyearReleased(){
    return yearReleased; 
}
int MovieData::GetrunningTime(){
    return runningTime;
}
double MovieData::GetproductionCost(){
    return productionCost;
}
double MovieData::GetfirstYearRevenues(){
    return firstYearRevenues;
}
MovieData::MovieData(){
        title = ""; 
        director = ""; 
        yearReleased = 0; 
        runningTime = 0; 
        productionCost = 0.0; 
        firstYearRevenues = 0.0; 
}